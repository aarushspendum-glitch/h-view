const SUPABASE_URL = 'https://xwbdeousohyqldivsoer.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3YmRlb3Vzb2h5cWxkaXZzb2VyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ5MjAwODAsImV4cCI6MjEwMDQ5NjA4MH0.BMjpnr8LQptZCT94XOfKcgrvx3XiCeObEl33yWqbeac';

export default async function handler(req, res) {
  if (req.method !== 'POST') { res.status(405).end(); return; }

  const deviceId = req.headers['x-device-id'] || 'default';
  const body = req.body;

  await fetch(`${SUPABASE_URL}/rest/v1/readings`, {
    method: 'POST',
    headers: {
      'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': 'application/json', 'Prefer': 'return=minimal'
    },
    body: JSON.stringify({
      device_id: deviceId,
      status: body.status,
      accel: body.accel,
      gyro: body.gyro,
      temp: body.temp,
      accel_sigma: body.accelSigma,
      gyro_sigma: body.gyroSigma,
      accel_base_mean: body.accelBaseMean,
      accel_base_std: body.accelBaseStd,
      gyro_base_mean: body.gyroBaseMean,
      gyro_base_std: body.gyroBaseStd
    })
  });

  res.status(200).end('OK');
}
