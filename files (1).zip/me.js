const SUPABASE_URL = 'https://xwbdeousohyqldivsoer.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3YmRlb3Vzb2h5cWxkaXZzb2VyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ5MjAwODAsImV4cCI6MjEwMDQ5NjA4MH0.BMjpnr8LQptZCT94XOfKcgrvx3XiCeObEl33yWqbeac';

async function getSession(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/sessions?token=eq.${token}&select=*`, {
    headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` }
  });
  const data = await res.json();
  return Array.isArray(data) && data.length > 0 ? data[0] : null;
}

export default async function handler(req, res) {
  const cookie = req.headers.cookie || '';
  const match = cookie.match(/hview_token=([^;]+)/);
  if (!match) { res.status(401).end(); return; }

  const session = await getSession(match[1]);
  if (!session) { res.status(401).end(); return; }

  res.status(200).json({ userId: session.user_id, email: session.email, role: session.role, name: session.name });
}
