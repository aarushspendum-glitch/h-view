const crypto = require('crypto');

const SUPABASE_URL = 'https://xwbdeousohyqldivsoer.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3YmRlb3Vzb2h5cWxkaXZzb2VyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ5MjAwODAsImV4cCI6MjEwMDQ5NjA4MH0.BMjpnr8LQptZCT94XOfKcgrvx3XiCeObEl33yWqbeac';

function hashPassword(p) {
  return crypto.createHash('sha256').update(p + 'hview-salt').digest('hex');
}

async function supabaseGet(table, query) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}${query}`, {
    headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` }
  });
  return res.json();
}

export default async function handler(req, res) {
  if (req.method !== 'POST') { res.status(405).end(); return; }

  const { email, password } = req.body;
  const hashed = hashPassword(password);

  const users = await supabaseGet('users', `?email=eq.${encodeURIComponent(email)}&password=eq.${hashed}`);

  if (!Array.isArray(users) || users.length === 0) {
    res.status(401).json({ error: 'Invalid email or password' });
    return;
  }

  const user = users[0];
  const token = crypto.randomBytes(32).toString('hex');

  // Store session in Supabase
  await fetch(`${SUPABASE_URL}/rest/v1/sessions`, {
    method: 'POST',
    headers: {
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=minimal'
    },
    body: JSON.stringify({ token, user_id: user.id, role: user.role, email: user.email, name: user.name })
  });

  res.setHeader('Set-Cookie', `hview_token=${token}; HttpOnly; Path=/; Max-Age=86400; SameSite=Lax`);
  res.status(200).json({ role: user.role, name: user.name });
}
