const SUPABASE_URL = 'https://xwbdeousohyqldivsoer.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3YmRlb3Vzb2h5cWxkaXZzb2VyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ5MjAwODAsImV4cCI6MjEwMDQ5NjA4MH0.BMjpnr8LQptZCT94XOfKcgrvx3XiCeObEl33yWqbeac';

export default async function handler(req, res) {
  const cookie = req.headers.cookie || '';
  const match = cookie.match(/hview_token=([^;]+)/);
  if (match) {
    await fetch(`${SUPABASE_URL}/rest/v1/sessions?token=eq.${match[1]}`, {
      method: 'DELETE',
      headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` }
    });
  }
  res.setHeader('Set-Cookie', 'hview_token=; Max-Age=0; Path=/');
  res.status(200).end('OK');
}
