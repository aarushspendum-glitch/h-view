const SUPABASE_URL = 'https://xwbdeousohyqldivsoer.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3YmRlb3Vzb2h5cWxkaXZzb2VyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ5MjAwODAsImV4cCI6MjEwMDQ5NjA4MH0.BMjpnr8LQptZCT94XOfKcgrvx3XiCeObEl33yWqbeac';

async function getSession(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/sessions?token=eq.${token}&select=*`, {
    headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` }
  });
  const data = await res.json();
  return Array.isArray(data) && data.length > 0 ? data[0] : null;
}

export default async function handler(req, res) {
  const cookie = req.headers.cookie || '';
  const match = cookie.match(/hview_token=([^;]+)/);
  if (!match) { res.status(401).end(); return; }

  const session = await getSession(match[1]);
  if (!session) { res.status(401).end(); return; }

  if (session.role === 'admin') {
    // Admin gets all latest readings per device
    const readings = await fetch(
      `${SUPABASE_URL}/rest/v1/readings?select=*&order=created_at.desc&limit=100`,
      { headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` } }
    ).then(r => r.json());

    // Group by device_id, keep latest
    const latest = {};
    for (const r of readings) {
      if (!latest[r.device_id]) latest[r.device_id] = r;
    }
    res.status(200).json(latest);
  } else {
    // Client gets their device's latest reading
    const devices = await fetch(
      `${SUPABASE_URL}/rest/v1/devices?user_id=eq.${session.user_id}&select=*`,
      { headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` } }
    ).then(r => r.json());

    if (!Array.isArray(devices) || devices.length === 0) {
      res.status(200).json({ status: 'WAITING' }); return;
    }

    const deviceId = devices[0].id;
    const readings = await fetch(
      `${SUPABASE_URL}/rest/v1/readings?device_id=eq.${deviceId}&select=*&order=created_at.desc&limit=1`,
      { headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` } }
    ).then(r => r.json());

    if (!Array.isArray(readings) || readings.length === 0) {
      res.status(200).json({ status: 'WAITING' }); return;
    }

    const r = readings[0];
    res.status(200).json({
      status: r.status, accel: r.accel, gyro: r.gyro, temp: r.temp,
      accelSigma: r.accel_sigma, gyroSigma: r.gyro_sigma,
      accelBaseMean: r.accel_base_mean, accelBaseStd: r.accel_base_std,
      gyroBaseMean: r.gyro_base_mean, gyroBaseStd: r.gyro_base_std,
      accelStatus: r.status, gyroStatus: r.status,
      receivedAt: r.created_at
    });
  }
}
