const crypto = require('crypto');
const SUPABASE_URL = 'https://xwbdeousohyqldivsoer.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3YmRlb3Vzb2h5cWxkaXZzb2VyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ5MjAwODAsImV4cCI6MjEwMDQ5NjA4MH0.BMjpnr8LQptZCT94XOfKcgrvx3XiCeObEl33yWqbeac';
const ADMIN_SECRET = 'hview-admin-2024';

function hashPassword(p) {
  return crypto.createHash('sha256').update(p + 'hview-salt').digest('hex');
}

export default async function handler(req, res) {
  if (req.method !== 'POST') { res.status(405).end(); return; }
  const { email, password, role, name, secret } = req.body;
  if (secret !== ADMIN_SECRET) { res.status(403).json({ error: 'Invalid secret' }); return; }

  const hashed = hashPassword(password);
  const result = await fetch(`${SUPABASE_URL}/rest/v1/users`, {
    method: 'POST',
    headers: {
      'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': 'application/json', 'Prefer': 'return=representation'
    },
    body: JSON.stringify({ email, password: hashed, role: role || 'client', name })
  });
  const data = await result.json();
  res.status(200).json({ success: true, user: data });
}
